const canvas = document.getElementById("gardenCanvas");
const ctx = canvas.getContext("2d");
const garden = JSON.parse(localStorage.getItem("garden") || "[]");

function drawFlower(x, y, data) {
  const emotions = Object.entries(data.emotions);
  const baseRadius = 40;
  const angleStep = (2 * Math.PI) / emotions.length;

  emotions.forEach(([emotion, value], i) => {
    const angle = i * angleStep;
    const radius = baseRadius + value * 30;
    drawPetal(x, y, angle, radius, emotion, value);
  });
}

function drawPetal(x, y, angle, radius, emotion, intensity) {
  const colors = {
    hope: `rgba(255, 215, 0, ${intensity})`,
    fear: `rgba(255, 0, 0, ${intensity})`,
    curiosity: `rgba(0, 191, 255, ${intensity})`,
    anxiety: `rgba(128, 0, 128, ${intensity})`,
    empowerment: `rgba(34, 139, 34, ${intensity})`,
  };
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(radius * 0.5, -radius / 2, 0, -radius);
  ctx.quadraticCurveTo(-radius * 0.5, -radius / 2, 0, 0);
  ctx.fillStyle = colors[emotion];
  ctx.fill();
  ctx.restore();
}

garden.forEach((entry, i) => {
  const x = 100 + (i % 5) * 150;
  const y = 100 + Math.floor(i / 5) * 150;
  drawFlower(x, y, entry);
});