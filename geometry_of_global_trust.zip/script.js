let sampleData = [];
fetch("gdc_flower_mock_data.json")
  .then(response => response.json())
  .then(data => {
    sampleData = data;
    populateSelectors();
  });

const canvas = document.getElementById("flowerCanvas");
const ctx = canvas.getContext("2d");

function drawFlower(data) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const emotions = Object.entries(data.emotions);
  const baseRadius = 70;
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const angleStep = (2 * Math.PI) / emotions.length;

  emotions.forEach(([emotion, value], i) => {
    const angle = i * angleStep;
    const radius = baseRadius + value * 50;
    drawPetal(centerX, centerY, angle, radius, emotion, value);
  });
}

function drawPetal(x, y, angle, radius, emotion, intensity) {
  const colors = {
    hope: `rgba(255, 215, 0, ${intensity})`,
    fear: `rgba(255, 0, 0, ${intensity})`,
    curiosity: `rgba(0, 191, 255, ${intensity})`,
    anxiety: `rgba(128, 0, 128, ${intensity})`,
    empowerment: `rgba(34, 139, 34, ${intensity})`,
  };
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(radius * 0.5, -radius / 2, 0, -radius);
  ctx.quadraticCurveTo(-radius * 0.5, -radius / 2, 0, 0);
  ctx.fillStyle = colors[emotion];
  ctx.fill();
  ctx.restore();
}

function populateSelectors() {
  const countries = [...new Set(sampleData.map(d => d.country))];
  const ages = [...new Set(sampleData.map(d => d.ageGroup))];
  const countrySel = document.getElementById("countrySelect");
  const ageSel = document.getElementById("ageSelect");

  countries.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    countrySel.appendChild(opt);
  });
  ages.forEach(a => {
    const opt = document.createElement("option");
    opt.value = a;
    opt.textContent = a;
    ageSel.appendChild(opt);
  });

  countrySel.onchange = update;
  ageSel.onchange = update;
}

function update() {
  const country = document.getElementById("countrySelect").value;
  const age = document.getElementById("ageSelect").value;
  const match = sampleData.find(d => d.country === country && d.ageGroup === age);
  if (match) drawFlower(match);
}

document.getElementById("saveFlower").onclick = () => {
  const newEntry = {
    country: document.getElementById("customCountry").value,
    ageGroup: document.getElementById("customAge").value,
    emotions: {
      hope: parseFloat(document.getElementById("hope").value),
      fear: parseFloat(document.getElementById("fear").value),
      curiosity: parseFloat(document.getElementById("curiosity").value),
      anxiety: parseFloat(document.getElementById("anxiety").value),
      empowerment: parseFloat(document.getElementById("empowerment").value),
    }
  };
  let garden = JSON.parse(localStorage.getItem("garden") || "[]");
  garden.push(newEntry);
  localStorage.setItem("garden", JSON.stringify(garden));
  alert("Flower saved!");
};