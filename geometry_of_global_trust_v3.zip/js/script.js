let data = [];
let customFlowers = JSON.parse(localStorage.getItem("gardenFlowers") || "[]");

fetch("data/gdc_flower_mock_data.json")
  .then((res) => res.json())
  .then((json) => {
    data = json;
    populateSelectors();
  });

function populateSelectors() {
  const countries = [...new Set(data.map(d => d.country))];
  const ages = [...new Set(data.map(d => d.ageGroup))];
  const countrySelect = document.getElementById("countrySelect");
  const ageSelect = document.getElementById("ageSelect");

  countries.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    countrySelect.appendChild(opt);
  });

  ages.forEach(a => {
    const opt = document.createElement("option");
    opt.value = a;
    opt.textContent = a;
    ageSelect.appendChild(opt);
  });

  countrySelect.onchange = drawSelected;
  ageSelect.onchange = drawSelected;
}

function drawSelected() {
  const c = document.getElementById("countrySelect").value;
  const a = document.getElementById("ageSelect").value;
  const flower = data.find(d => d.country === c && d.ageGroup === a);
  if (flower) drawFlower(flower);
}

function drawFlower(entry) {
  const canvas = document.getElementById("flowerCanvas");
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const x = canvas.width / 2, y = canvas.height / 2;
  const emotions = entry.emotions;
  const colors = {
    hope: "gold",
    fear: "red",
    curiosity: "deepskyblue",
    anxiety: "purple",
    empowerment: "forestgreen"
  };
  const keys = Object.keys(emotions);
  keys.forEach((emotion, i) => {
    const angle = (i * 2 * Math.PI) / keys.length;
    const r = 40 + emotions[emotion] * 80;
    const cx = x + r * Math.cos(angle);
    const cy = y + r * Math.sin(angle);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(cx, cy, 20, 0, 2 * Math.PI);
    ctx.fillStyle = colors[emotion];
    ctx.fill();
  });
}

document.getElementById("addFlower").onclick = () => {
  const newFlower = {
    country: document.getElementById("customCountry").value,
    ageGroup: document.getElementById("customAge").value,
    emotions: {
      hope: parseFloat(document.getElementById("hope").value),
      fear: parseFloat(document.getElementById("fear").value),
      curiosity: parseFloat(document.getElementById("curiosity").value),
      anxiety: parseFloat(document.getElementById("anxiety").value),
      empowerment: parseFloat(document.getElementById("empowerment").value)
    }
  };
  customFlowers.push(newFlower);
  localStorage.setItem("gardenFlowers", JSON.stringify(customFlowers));
  alert("Flower added to the garden!");
};
