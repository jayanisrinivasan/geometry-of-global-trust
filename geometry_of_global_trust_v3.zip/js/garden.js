const garden = JSON.parse(localStorage.getItem("gardenFlowers") || "[]");
const container = document.getElementById("gardenFlowers");

garden.forEach((entry, i) => {
  const canvas = document.createElement("canvas");
  canvas.width = 200;
  canvas.height = 200;
  container.appendChild(canvas);
  const ctx = canvas.getContext("2d");
  const x = 100, y = 100;
  const emotions = entry.emotions;
  const colors = {
    hope: "gold",
    fear: "red",
    curiosity: "deepskyblue",
    anxiety: "purple",
    empowerment: "forestgreen"
  };
  const keys = Object.keys(emotions);
  keys.forEach((emotion, j) => {
    const angle = (j * 2 * Math.PI) / keys.length;
    const r = 30 + emotions[emotion] * 60;
    const cx = x + r * Math.cos(angle);
    const cy = y + r * Math.sin(angle);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.arc(cx, cy, 15, 0, 2 * Math.PI);
    ctx.fillStyle = colors[emotion];
    ctx.fill();
  });
});
